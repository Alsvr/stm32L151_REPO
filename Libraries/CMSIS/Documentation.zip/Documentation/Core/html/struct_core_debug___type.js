var struct_core_debug___type =
[
    [ "DCRDR", "struct_core_debug___type.html#ab8f4bb076402b61f7be6308075a789c9", null ],
    [ "DCRSR", "struct_core_debug___type.html#afefa84bce7497652353a1b76d405d983", null ],
    [ "DEMCR", "struct_core_debug___type.html#a5cdd51dbe3ebb7041880714430edd52d", null ],
    [ "DHCSR", "struct_core_debug___type.html#a25c14c022c73a725a1736e903431095d", null ]
];