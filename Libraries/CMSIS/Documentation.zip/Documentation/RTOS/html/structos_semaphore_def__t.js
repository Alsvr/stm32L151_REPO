var structos_semaphore_def__t =
[
    [ "dummy", "structos_semaphore_def__t.html#a44b7a3baf02bac7ad707e8f2f5eca1ca", null ]
];